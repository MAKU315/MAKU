import sys
def main():
    for arg in sys.argv[0:]:
        print(arg)
if __name__ == "__main__":
    main()